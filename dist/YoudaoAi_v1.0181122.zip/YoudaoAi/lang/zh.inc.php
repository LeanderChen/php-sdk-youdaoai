<?php

// access id & access key 相关
define('NOT_SET_APP_KEY', '未设置服务的APP_KEY');
define('NOT_SET_SEC_KEY', '未设置服务的SEC_KEY');
define('NOT_SET_APP_KEY_AND_SEC_KEY', '没有设置APP_KEY或SEC_KEY');
define('NOT_SET_API_SERV', '未设置API服务器');
define('NOT_SET_API_PATH', '未设置API路径');

// 自然语言翻译相关
define('TRANS_NOT_SUPPORT_LANGUAGE', '不支持的翻译语言');
