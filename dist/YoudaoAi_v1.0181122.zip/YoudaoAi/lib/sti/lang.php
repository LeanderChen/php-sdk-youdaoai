<?php
$lang = array(
    'zh-CHS',       // 中文
    'ja',           // 日文
    'EN',           // 英文
    'ko',           // 韩文
    'fr',           // 法文
    'ru',           // 俄文
    'pt',           // 葡萄牙文
    'es',           // 西班牙文
);
	
	
	
	
	
	
	
	
	
	
	
	